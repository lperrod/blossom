package com.blossomproject.module.filemanager;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.Generated;
import com.querydsl.core.types.Path;


/**
 * QFileContent is a Querydsl query type for FileContent
 */
@Generated("com.querydsl.codegen.EntitySerializer")
public class QFileContent extends EntityPathBase<FileContent> {

    private static final long serialVersionUID = -1358646615L;

    public static final QFileContent fileContent = new QFileContent("fileContent");

    public final com.blossomproject.core.common.entity.QAbstractEntity _super = new com.blossomproject.core.common.entity.QAbstractEntity(this);

    //inherited
    public final DateTimePath<java.util.Date> creationDate = _super.creationDate;

    //inherited
    public final StringPath creationUser = _super.creationUser;

    public final ArrayPath<byte[], Byte> data = createArray("data", byte[].class);

    public final NumberPath<Long> fileId = createNumber("fileId", Long.class);

    //inherited
    public final NumberPath<Long> id = _super.id;

    //inherited
    public final DateTimePath<java.util.Date> modificationDate = _super.modificationDate;

    //inherited
    public final StringPath modificationUser = _super.modificationUser;

    public QFileContent(String variable) {
        super(FileContent.class, forVariable(variable));
    }

    public QFileContent(Path<? extends FileContent> path) {
        super(path.getType(), path.getMetadata());
    }

    public QFileContent(PathMetadata metadata) {
        super(FileContent.class, metadata);
    }

}

