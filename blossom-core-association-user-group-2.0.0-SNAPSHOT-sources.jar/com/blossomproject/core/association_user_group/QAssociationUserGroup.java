package com.blossomproject.core.association_user_group;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QAssociationUserGroup is a Querydsl query type for AssociationUserGroup
 */
@Generated("com.querydsl.codegen.EntitySerializer")
public class QAssociationUserGroup extends EntityPathBase<AssociationUserGroup> {

    private static final long serialVersionUID = 1144183668L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QAssociationUserGroup associationUserGroup = new QAssociationUserGroup("associationUserGroup");

    public final com.blossomproject.core.common.entity.QAbstractAssociationEntity _super;

    public final com.blossomproject.core.user.QUser a;

    public final com.blossomproject.core.group.QGroup b;

    //inherited
    public final DateTimePath<java.util.Date> creationDate;

    //inherited
    public final StringPath creationUser;

    //inherited
    public final NumberPath<Long> id;

    //inherited
    public final DateTimePath<java.util.Date> modificationDate;

    //inherited
    public final StringPath modificationUser;

    public QAssociationUserGroup(String variable) {
        this(AssociationUserGroup.class, forVariable(variable), INITS);
    }

    public QAssociationUserGroup(Path<? extends AssociationUserGroup> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QAssociationUserGroup(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QAssociationUserGroup(PathMetadata metadata, PathInits inits) {
        this(AssociationUserGroup.class, metadata, inits);
    }

    public QAssociationUserGroup(Class<? extends AssociationUserGroup> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this._super = new com.blossomproject.core.common.entity.QAbstractAssociationEntity(type, metadata, inits);
        this.a = inits.isInitialized("a") ? new com.blossomproject.core.user.QUser(forProperty("a")) : null;
        this.b = inits.isInitialized("b") ? new com.blossomproject.core.group.QGroup(forProperty("b")) : null;
        this.creationDate = _super.creationDate;
        this.creationUser = _super.creationUser;
        this.id = _super.id;
        this.modificationDate = _super.modificationDate;
        this.modificationUser = _super.modificationUser;
    }

}

