package com.blossomproject.core.association_user_role;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QAssociationUserRole is a Querydsl query type for AssociationUserRole
 */
@Generated("com.querydsl.codegen.EntitySerializer")
public class QAssociationUserRole extends EntityPathBase<AssociationUserRole> {

    private static final long serialVersionUID = 669317820L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QAssociationUserRole associationUserRole = new QAssociationUserRole("associationUserRole");

    public final com.blossomproject.core.common.entity.QAbstractAssociationEntity _super;

    public final com.blossomproject.core.user.QUser a;

    public final com.blossomproject.core.role.QRole b;

    //inherited
    public final DateTimePath<java.util.Date> creationDate;

    //inherited
    public final StringPath creationUser;

    //inherited
    public final NumberPath<Long> id;

    //inherited
    public final DateTimePath<java.util.Date> modificationDate;

    //inherited
    public final StringPath modificationUser;

    public QAssociationUserRole(String variable) {
        this(AssociationUserRole.class, forVariable(variable), INITS);
    }

    public QAssociationUserRole(Path<? extends AssociationUserRole> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QAssociationUserRole(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QAssociationUserRole(PathMetadata metadata, PathInits inits) {
        this(AssociationUserRole.class, metadata, inits);
    }

    public QAssociationUserRole(Class<? extends AssociationUserRole> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this._super = new com.blossomproject.core.common.entity.QAbstractAssociationEntity(type, metadata, inits);
        this.a = inits.isInitialized("a") ? new com.blossomproject.core.user.QUser(forProperty("a")) : null;
        this.b = inits.isInitialized("b") ? new com.blossomproject.core.role.QRole(forProperty("b")) : null;
        this.creationDate = _super.creationDate;
        this.creationUser = _super.creationUser;
        this.id = _super.id;
        this.modificationDate = _super.modificationDate;
        this.modificationUser = _super.modificationUser;
    }

}

