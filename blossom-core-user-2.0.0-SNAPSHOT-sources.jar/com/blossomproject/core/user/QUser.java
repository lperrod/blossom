package com.blossomproject.core.user;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.Generated;
import com.querydsl.core.types.Path;


/**
 * QUser is a Querydsl query type for User
 */
@Generated("com.querydsl.codegen.EntitySerializer")
public class QUser extends EntityPathBase<User> {

    private static final long serialVersionUID = 557592394L;

    public static final QUser user = new QUser("user");

    public final com.blossomproject.core.common.entity.QAbstractEntity _super = new com.blossomproject.core.common.entity.QAbstractEntity(this);

    public final BooleanPath activated = createBoolean("activated");

    public final ArrayPath<byte[], Byte> avatar = createArray("avatar", byte[].class);

    public final EnumPath<User.Civility> civility = createEnum("civility", User.Civility.class);

    public final StringPath company = createString("company");

    //inherited
    public final DateTimePath<java.util.Date> creationDate = _super.creationDate;

    //inherited
    public final StringPath creationUser = _super.creationUser;

    public final StringPath description = createString("description");

    public final StringPath email = createString("email");

    public final StringPath firstname = createString("firstname");

    public final StringPath function = createString("function");

    //inherited
    public final NumberPath<Long> id = _super.id;

    public final StringPath identifier = createString("identifier");

    public final DateTimePath<java.util.Date> lastConnection = createDateTime("lastConnection", java.util.Date.class);

    public final StringPath lastname = createString("lastname");

    public final SimplePath<java.util.Locale> locale = createSimple("locale", java.util.Locale.class);

    //inherited
    public final DateTimePath<java.util.Date> modificationDate = _super.modificationDate;

    //inherited
    public final StringPath modificationUser = _super.modificationUser;

    public final StringPath passwordHash = createString("passwordHash");

    public final StringPath phone = createString("phone");

    public QUser(String variable) {
        super(User.class, forVariable(variable));
    }

    public QUser(Path<? extends User> path) {
        super(path.getType(), path.getMetadata());
    }

    public QUser(PathMetadata metadata) {
        super(User.class, metadata);
    }

}

