package com.blossomproject.core.common.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QAbstractAssociationEntity is a Querydsl query type for AbstractAssociationEntity
 */
@Generated("com.querydsl.codegen.SupertypeSerializer")
public class QAbstractAssociationEntity extends EntityPathBase<AbstractAssociationEntity<? extends AbstractEntity, ? extends AbstractEntity>> {

    private static final long serialVersionUID = 1712027414L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QAbstractAssociationEntity abstractAssociationEntity = new QAbstractAssociationEntity("abstractAssociationEntity");

    public final QAbstractEntity _super = new QAbstractEntity(this);

    public final QAbstractEntity a;

    public final QAbstractEntity b;

    //inherited
    public final DateTimePath<java.util.Date> creationDate = _super.creationDate;

    //inherited
    public final StringPath creationUser = _super.creationUser;

    //inherited
    public final NumberPath<Long> id = _super.id;

    //inherited
    public final DateTimePath<java.util.Date> modificationDate = _super.modificationDate;

    //inherited
    public final StringPath modificationUser = _super.modificationUser;

    @SuppressWarnings({"all", "rawtypes", "unchecked"})
    public QAbstractAssociationEntity(String variable) {
        this((Class) AbstractAssociationEntity.class, forVariable(variable), INITS);
    }

    @SuppressWarnings({"all", "rawtypes", "unchecked"})
    public QAbstractAssociationEntity(Path<? extends AbstractAssociationEntity> path) {
        this((Class) path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QAbstractAssociationEntity(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    @SuppressWarnings({"all", "rawtypes", "unchecked"})
    public QAbstractAssociationEntity(PathMetadata metadata, PathInits inits) {
        this((Class) AbstractAssociationEntity.class, metadata, inits);
    }

    public QAbstractAssociationEntity(Class<? extends AbstractAssociationEntity<? extends AbstractEntity, ? extends AbstractEntity>> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.a = inits.isInitialized("a") ? new QAbstractEntity(forProperty("a")) : null;
        this.b = inits.isInitialized("b") ? new QAbstractEntity(forProperty("b")) : null;
    }

}

