package com.blossomproject.module.article;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.Generated;
import com.querydsl.core.types.Path;


/**
 * QArticle is a Querydsl query type for Article
 */
@Generated("com.querydsl.codegen.EntitySerializer")
public class QArticle extends EntityPathBase<Article> {

    private static final long serialVersionUID = -346238969L;

    public static final QArticle article = new QArticle("article");

    public final com.blossomproject.core.common.entity.QAbstractEntity _super = new com.blossomproject.core.common.entity.QAbstractEntity(this);

    public final StringPath content = createString("content");

    //inherited
    public final DateTimePath<java.util.Date> creationDate = _super.creationDate;

    //inherited
    public final StringPath creationUser = _super.creationUser;

    //inherited
    public final NumberPath<Long> id = _super.id;

    //inherited
    public final DateTimePath<java.util.Date> modificationDate = _super.modificationDate;

    //inherited
    public final StringPath modificationUser = _super.modificationUser;

    public final StringPath name = createString("name");

    public final EnumPath<Article.Status> status = createEnum("status", Article.Status.class);

    public final StringPath summary = createString("summary");

    public QArticle(String variable) {
        super(Article.class, forVariable(variable));
    }

    public QArticle(Path<? extends Article> path) {
        super(path.getType(), path.getMetadata());
    }

    public QArticle(PathMetadata metadata) {
        super(Article.class, metadata);
    }

}

